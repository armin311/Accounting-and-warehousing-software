﻿namespace HesabdariAnbardari
{
    partial class frmFactorFroosh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFactorFroosh));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.groupPanel9 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.btnSanad = new DevComponents.DotNetBar.ButtonX();
            this.btnPardakht = new DevComponents.DotNetBar.ButtonX();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.btnSave = new DevComponents.DotNetBar.ButtonX();
            this.groupPanel8 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.dblFroosh = new DevComponents.Editors.DoubleInput();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtHazineh = new DevComponents.Editors.IntegerInput();
            this.txtTakhfif = new DevComponents.Editors.IntegerInput();
            this.txtJameKol = new DevComponents.Editors.IntegerInput();
            this.txtMaliyat = new DevComponents.Editors.IntegerInput();
            this.txtJameFactor = new DevComponents.Editors.IntegerInput();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupPanel7 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.txtFilterKala = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.dgvKala = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.groupPanel6 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.dgvMoshtari = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.txtFilterMoshtari = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.groupPanel5 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.dgvFactor = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.IdKala = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameKala = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GeymatFroosh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GeymatKharid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tedad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GeymatKolFroosh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GeymatKolKharid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupPanel4 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.btnPrint = new DevComponents.DotNetBar.ButtonX();
            this.btnDelete = new DevComponents.DotNetBar.ButtonX();
            this.btnAdd = new DevComponents.DotNetBar.ButtonX();
            this.label16 = new System.Windows.Forms.Label();
            this.lblTedad = new System.Windows.Forms.Label();
            this.groupPanel3 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.txtGeymatKharid = new DevComponents.Editors.IntegerInput();
            this.label15 = new System.Windows.Forms.Label();
            this.txtTedad = new DevComponents.Editors.IntegerInput();
            this.txtIdKala = new DevComponents.Editors.IntegerInput();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTozih = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtIdMoshtari = new DevComponents.Editors.IntegerInput();
            this.txtGeymatFroosh = new DevComponents.Editors.IntegerInput();
            this.txtMobile = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtNameKala = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtNameMoshtari = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupPanel2 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.txtCodeFactor = new DevComponents.Editors.IntegerInput();
            this.mskTarikh = new DevComponents.DotNetBar.Controls.MaskedTextBoxAdv();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupPanel1.SuspendLayout();
            this.groupPanel9.SuspendLayout();
            this.groupPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dblFroosh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHazineh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTakhfif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJameKol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaliyat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJameFactor)).BeginInit();
            this.groupPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKala)).BeginInit();
            this.groupPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMoshtari)).BeginInit();
            this.groupPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFactor)).BeginInit();
            this.groupPanel4.SuspendLayout();
            this.groupPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeymatKharid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTedad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIdKala)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIdMoshtari)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeymatFroosh)).BeginInit();
            this.groupPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCodeFactor)).BeginInit();
            this.SuspendLayout();
            // 
            // groupPanel1
            // 
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.groupPanel9);
            this.groupPanel1.Controls.Add(this.groupPanel8);
            this.groupPanel1.Controls.Add(this.groupPanel7);
            this.groupPanel1.Controls.Add(this.groupPanel6);
            this.groupPanel1.Controls.Add(this.groupPanel5);
            this.groupPanel1.Controls.Add(this.groupPanel4);
            this.groupPanel1.Controls.Add(this.groupPanel3);
            this.groupPanel1.Controls.Add(this.groupPanel2);
            this.groupPanel1.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1.Location = new System.Drawing.Point(0, 0);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(915, 482);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 1;
            // 
            // groupPanel9
            // 
            this.groupPanel9.BackColor = System.Drawing.Color.Transparent;
            this.groupPanel9.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel9.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel9.Controls.Add(this.btnSanad);
            this.groupPanel9.Controls.Add(this.btnPardakht);
            this.groupPanel9.Controls.Add(this.buttonX2);
            this.groupPanel9.Controls.Add(this.buttonX1);
            this.groupPanel9.Controls.Add(this.btnSave);
            this.groupPanel9.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel9.Location = new System.Drawing.Point(4, 431);
            this.groupPanel9.Name = "groupPanel9";
            this.groupPanel9.Size = new System.Drawing.Size(642, 43);
            // 
            // 
            // 
            this.groupPanel9.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel9.Style.BackColorGradientAngle = 90;
            this.groupPanel9.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel9.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel9.Style.BorderBottomWidth = 1;
            this.groupPanel9.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel9.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel9.Style.BorderLeftWidth = 1;
            this.groupPanel9.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel9.Style.BorderRightWidth = 1;
            this.groupPanel9.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel9.Style.BorderTopWidth = 1;
            this.groupPanel9.Style.CornerDiameter = 4;
            this.groupPanel9.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel9.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel9.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel9.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel9.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel9.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel9.TabIndex = 7;
            // 
            // btnSanad
            // 
            this.btnSanad.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnSanad.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnSanad.Image = ((System.Drawing.Image)(resources.GetObject("btnSanad.Image")));
            this.btnSanad.Location = new System.Drawing.Point(1, 0);
            this.btnSanad.Name = "btnSanad";
            this.btnSanad.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8, 8, 2, 2);
            this.btnSanad.Size = new System.Drawing.Size(103, 37);
            this.btnSanad.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnSanad.TabIndex = 0;
            this.btnSanad.Text = "دریافت سند";
            this.btnSanad.Click += new System.EventHandler(this.btnSanad_Click);
            // 
            // btnPardakht
            // 
            this.btnPardakht.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnPardakht.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnPardakht.Image = ((System.Drawing.Image)(resources.GetObject("btnPardakht.Image")));
            this.btnPardakht.Location = new System.Drawing.Point(110, 0);
            this.btnPardakht.Name = "btnPardakht";
            this.btnPardakht.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8, 8, 2, 2);
            this.btnPardakht.Size = new System.Drawing.Size(92, 37);
            this.btnPardakht.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnPardakht.TabIndex = 4;
            this.btnPardakht.Text = "دریافت نقد";
            this.btnPardakht.Click += new System.EventHandler(this.btnPardakht_Click);
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.Image = ((System.Drawing.Image)(resources.GetObject("buttonX2.Image")));
            this.buttonX2.Location = new System.Drawing.Point(477, 0);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8, 8, 2, 2);
            this.buttonX2.Size = new System.Drawing.Size(159, 37);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 1;
            this.buttonX2.Text = "محاسبه نهایی فاکتور";
            this.buttonX2.Click += new System.EventHandler(this.buttonX2_Click);
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Image = ((System.Drawing.Image)(resources.GetObject("buttonX1.Image")));
            this.buttonX1.Location = new System.Drawing.Point(205, 0);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8, 8, 2, 2);
            this.buttonX1.Size = new System.Drawing.Size(170, 37);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.TabIndex = 3;
            this.buttonX1.Text = "لیست فاکتورهای فروش";
            this.buttonX1.Click += new System.EventHandler(this.buttonX1_Click);
            // 
            // btnSave
            // 
            this.btnSave.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnSave.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(377, 0);
            this.btnSave.Name = "btnSave";
            this.btnSave.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8, 8, 2, 2);
            this.btnSave.Size = new System.Drawing.Size(98, 37);
            this.btnSave.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "ثبت";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupPanel8
            // 
            this.groupPanel8.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel8.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel8.Controls.Add(this.dblFroosh);
            this.groupPanel8.Controls.Add(this.label13);
            this.groupPanel8.Controls.Add(this.label12);
            this.groupPanel8.Controls.Add(this.txtHazineh);
            this.groupPanel8.Controls.Add(this.txtTakhfif);
            this.groupPanel8.Controls.Add(this.txtJameKol);
            this.groupPanel8.Controls.Add(this.txtMaliyat);
            this.groupPanel8.Controls.Add(this.txtJameFactor);
            this.groupPanel8.Controls.Add(this.label10);
            this.groupPanel8.Controls.Add(this.label11);
            this.groupPanel8.Controls.Add(this.label9);
            this.groupPanel8.Controls.Add(this.label3);
            this.groupPanel8.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel8.Location = new System.Drawing.Point(4, 362);
            this.groupPanel8.Name = "groupPanel8";
            this.groupPanel8.Size = new System.Drawing.Size(642, 66);
            // 
            // 
            // 
            this.groupPanel8.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel8.Style.BackColorGradientAngle = 90;
            this.groupPanel8.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel8.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel8.Style.BorderBottomWidth = 1;
            this.groupPanel8.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel8.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel8.Style.BorderLeftWidth = 1;
            this.groupPanel8.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel8.Style.BorderRightWidth = 1;
            this.groupPanel8.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel8.Style.BorderTopWidth = 1;
            this.groupPanel8.Style.CornerDiameter = 4;
            this.groupPanel8.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel8.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel8.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel8.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel8.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel8.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel8.TabIndex = 4;
            // 
            // dblFroosh
            // 
            this.dblFroosh.AllowEmptyState = false;
            // 
            // 
            // 
            this.dblFroosh.BackgroundStyle.Class = "DateTimeInputBackground";
            this.dblFroosh.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dblFroosh.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.dblFroosh.Increment = 1D;
            this.dblFroosh.Location = new System.Drawing.Point(227, 1);
            this.dblFroosh.MinValue = 0D;
            this.dblFroosh.Name = "dblFroosh";
            this.dblFroosh.ShowUpDown = true;
            this.dblFroosh.Size = new System.Drawing.Size(78, 22);
            this.dblFroosh.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(135, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "جمع مبلغ فاکتور";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Location = new System.Drawing.Point(362, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 14);
            this.label12.TabIndex = 0;
            this.label12.Text = "تخفیف";
            // 
            // txtHazineh
            // 
            // 
            // 
            // 
            this.txtHazineh.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtHazineh.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtHazineh.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtHazineh.Location = new System.Drawing.Point(407, 32);
            this.txtHazineh.Name = "txtHazineh";
            this.txtHazineh.Size = new System.Drawing.Size(131, 22);
            this.txtHazineh.TabIndex = 3;
            // 
            // txtTakhfif
            // 
            // 
            // 
            // 
            this.txtTakhfif.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTakhfif.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTakhfif.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTakhfif.Location = new System.Drawing.Point(227, 32);
            this.txtTakhfif.Name = "txtTakhfif";
            this.txtTakhfif.Size = new System.Drawing.Size(131, 22);
            this.txtTakhfif.TabIndex = 4;
            // 
            // txtJameKol
            // 
            // 
            // 
            // 
            this.txtJameKol.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtJameKol.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtJameKol.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtJameKol.Location = new System.Drawing.Point(3, 32);
            this.txtJameKol.Name = "txtJameKol";
            this.txtJameKol.Size = new System.Drawing.Size(131, 22);
            this.txtJameKol.TabIndex = 5;
            // 
            // txtMaliyat
            // 
            // 
            // 
            // 
            this.txtMaliyat.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtMaliyat.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtMaliyat.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtMaliyat.Location = new System.Drawing.Point(4, 0);
            this.txtMaliyat.Name = "txtMaliyat";
            this.txtMaliyat.Size = new System.Drawing.Size(131, 22);
            this.txtMaliyat.TabIndex = 2;
            // 
            // txtJameFactor
            // 
            // 
            // 
            // 
            this.txtJameFactor.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtJameFactor.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtJameFactor.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtJameFactor.Location = new System.Drawing.Point(407, 0);
            this.txtJameFactor.Name = "txtJameFactor";
            this.txtJameFactor.Size = new System.Drawing.Size(131, 22);
            this.txtJameFactor.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(135, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 14);
            this.label10.TabIndex = 0;
            this.label10.Text = "ارزش افزوده کل";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Location = new System.Drawing.Point(544, 36);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 14);
            this.label11.TabIndex = 0;
            this.label11.Text = "هزینه خدمات";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(304, 4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 14);
            this.label9.TabIndex = 0;
            this.label9.Text = "درصد ارزش افزوده";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(544, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 14);
            this.label3.TabIndex = 0;
            this.label3.Text = "جمع مبلغ کالاها";
            // 
            // groupPanel7
            // 
            this.groupPanel7.BackColor = System.Drawing.Color.Transparent;
            this.groupPanel7.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel7.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel7.Controls.Add(this.txtFilterKala);
            this.groupPanel7.Controls.Add(this.dgvKala);
            this.groupPanel7.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel7.Location = new System.Drawing.Point(652, 246);
            this.groupPanel7.Name = "groupPanel7";
            this.groupPanel7.Size = new System.Drawing.Size(250, 228);
            // 
            // 
            // 
            this.groupPanel7.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel7.Style.BackColorGradientAngle = 90;
            this.groupPanel7.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel7.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel7.Style.BorderBottomWidth = 1;
            this.groupPanel7.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel7.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel7.Style.BorderLeftWidth = 1;
            this.groupPanel7.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel7.Style.BorderRightWidth = 1;
            this.groupPanel7.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel7.Style.BorderTopWidth = 1;
            this.groupPanel7.Style.CornerDiameter = 4;
            this.groupPanel7.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel7.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel7.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel7.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel7.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel7.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel7.TabIndex = 6;
            this.groupPanel7.Text = "انتخاب کالا";
            // 
            // txtFilterKala
            // 
            // 
            // 
            // 
            this.txtFilterKala.Border.Class = "TextBoxBorder";
            this.txtFilterKala.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtFilterKala.Location = new System.Drawing.Point(5, 3);
            this.txtFilterKala.Name = "txtFilterKala";
            this.txtFilterKala.PreventEnterBeep = true;
            this.txtFilterKala.Size = new System.Drawing.Size(236, 22);
            this.txtFilterKala.TabIndex = 0;
            this.txtFilterKala.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFilterKala.WatermarkText = "نام کالارا جست جو کنید";
            this.txtFilterKala.TextChanged += new System.EventHandler(this.txtFilterKala_TextChanged);
            // 
            // dgvKala
            // 
            this.dgvKala.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvKala.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvKala.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvKala.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvKala.EnableHeadersVisualStyles = false;
            this.dgvKala.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvKala.Location = new System.Drawing.Point(3, 30);
            this.dgvKala.Name = "dgvKala";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvKala.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvKala.Size = new System.Drawing.Size(240, 174);
            this.dgvKala.TabIndex = 1;
            this.dgvKala.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgvKala_MouseUp);
            // 
            // groupPanel6
            // 
            this.groupPanel6.BackColor = System.Drawing.Color.Transparent;
            this.groupPanel6.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel6.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel6.Controls.Add(this.dgvMoshtari);
            this.groupPanel6.Controls.Add(this.txtFilterMoshtari);
            this.groupPanel6.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel6.Location = new System.Drawing.Point(652, 3);
            this.groupPanel6.Name = "groupPanel6";
            this.groupPanel6.Size = new System.Drawing.Size(250, 237);
            // 
            // 
            // 
            this.groupPanel6.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel6.Style.BackColorGradientAngle = 90;
            this.groupPanel6.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel6.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderBottomWidth = 1;
            this.groupPanel6.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel6.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderLeftWidth = 1;
            this.groupPanel6.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderRightWidth = 1;
            this.groupPanel6.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel6.Style.BorderTopWidth = 1;
            this.groupPanel6.Style.CornerDiameter = 4;
            this.groupPanel6.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel6.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel6.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel6.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel6.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel6.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel6.TabIndex = 5;
            this.groupPanel6.Text = "انتخاب مشتری";
            // 
            // dgvMoshtari
            // 
            this.dgvMoshtari.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMoshtari.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvMoshtari.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMoshtari.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvMoshtari.EnableHeadersVisualStyles = false;
            this.dgvMoshtari.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvMoshtari.Location = new System.Drawing.Point(3, 32);
            this.dgvMoshtari.Name = "dgvMoshtari";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMoshtari.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvMoshtari.Size = new System.Drawing.Size(240, 179);
            this.dgvMoshtari.TabIndex = 1;
            this.dgvMoshtari.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgvMoshtari_MouseUp);
            // 
            // txtFilterMoshtari
            // 
            // 
            // 
            // 
            this.txtFilterMoshtari.Border.Class = "TextBoxBorder";
            this.txtFilterMoshtari.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtFilterMoshtari.Location = new System.Drawing.Point(3, 4);
            this.txtFilterMoshtari.Name = "txtFilterMoshtari";
            this.txtFilterMoshtari.PreventEnterBeep = true;
            this.txtFilterMoshtari.Size = new System.Drawing.Size(236, 22);
            this.txtFilterMoshtari.TabIndex = 0;
            this.txtFilterMoshtari.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtFilterMoshtari.WatermarkText = "نام مشتری را جست جو کنید";
            this.txtFilterMoshtari.TextChanged += new System.EventHandler(this.txtFilterMoshtari_TextChanged);
            // 
            // groupPanel5
            // 
            this.groupPanel5.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel5.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel5.Controls.Add(this.dgvFactor);
            this.groupPanel5.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel5.Location = new System.Drawing.Point(4, 175);
            this.groupPanel5.Name = "groupPanel5";
            this.groupPanel5.Size = new System.Drawing.Size(642, 181);
            // 
            // 
            // 
            this.groupPanel5.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel5.Style.BackColorGradientAngle = 90;
            this.groupPanel5.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel5.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel5.Style.BorderBottomWidth = 1;
            this.groupPanel5.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel5.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel5.Style.BorderLeftWidth = 1;
            this.groupPanel5.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel5.Style.BorderRightWidth = 1;
            this.groupPanel5.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel5.Style.BorderTopWidth = 1;
            this.groupPanel5.Style.CornerDiameter = 4;
            this.groupPanel5.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel5.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel5.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel5.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel5.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel5.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel5.TabIndex = 3;
            // 
            // dgvFactor
            // 
            this.dgvFactor.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFactor.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvFactor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFactor.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdKala,
            this.NameKala,
            this.GeymatFroosh,
            this.GeymatKharid,
            this.Tedad,
            this.GeymatKolFroosh,
            this.GeymatKolKharid});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvFactor.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgvFactor.EnableHeadersVisualStyles = false;
            this.dgvFactor.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dgvFactor.Location = new System.Drawing.Point(4, 0);
            this.dgvFactor.Name = "dgvFactor";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFactor.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvFactor.Size = new System.Drawing.Size(629, 172);
            this.dgvFactor.TabIndex = 0;
            // 
            // IdKala
            // 
            this.IdKala.HeaderText = "کد کالا";
            this.IdKala.Name = "IdKala";
            this.IdKala.Width = 70;
            // 
            // NameKala
            // 
            this.NameKala.HeaderText = "نام کالا";
            this.NameKala.Name = "NameKala";
            this.NameKala.Width = 200;
            // 
            // GeymatFroosh
            // 
            this.GeymatFroosh.HeaderText = "قیمت فروش";
            this.GeymatFroosh.Name = "GeymatFroosh";
            // 
            // GeymatKharid
            // 
            this.GeymatKharid.HeaderText = "قیمت خرید";
            this.GeymatKharid.Name = "GeymatKharid";
            // 
            // Tedad
            // 
            this.Tedad.HeaderText = "تعداد";
            this.Tedad.Name = "Tedad";
            // 
            // GeymatKolFroosh
            // 
            this.GeymatKolFroosh.HeaderText = "قیمت کل فروش";
            this.GeymatKolFroosh.Name = "GeymatKolFroosh";
            // 
            // GeymatKolKharid
            // 
            this.GeymatKolKharid.HeaderText = "قیمت کل خرید";
            this.GeymatKolKharid.Name = "GeymatKolKharid";
            // 
            // groupPanel4
            // 
            this.groupPanel4.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel4.Controls.Add(this.btnPrint);
            this.groupPanel4.Controls.Add(this.btnDelete);
            this.groupPanel4.Controls.Add(this.btnAdd);
            this.groupPanel4.Controls.Add(this.label16);
            this.groupPanel4.Controls.Add(this.lblTedad);
            this.groupPanel4.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel4.Location = new System.Drawing.Point(4, 126);
            this.groupPanel4.Name = "groupPanel4";
            this.groupPanel4.Size = new System.Drawing.Size(642, 45);
            // 
            // 
            // 
            this.groupPanel4.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel4.Style.BackColorGradientAngle = 90;
            this.groupPanel4.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel4.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel4.Style.BorderBottomWidth = 1;
            this.groupPanel4.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel4.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel4.Style.BorderLeftWidth = 1;
            this.groupPanel4.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel4.Style.BorderRightWidth = 1;
            this.groupPanel4.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel4.Style.BorderTopWidth = 1;
            this.groupPanel4.Style.CornerDiameter = 4;
            this.groupPanel4.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel4.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel4.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel4.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel4.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel4.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel4.TabIndex = 2;
            // 
            // btnPrint
            // 
            this.btnPrint.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnPrint.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnPrint.Image = ((System.Drawing.Image)(resources.GetObject("btnPrint.Image")));
            this.btnPrint.Location = new System.Drawing.Point(163, 0);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(8, 8, 2, 2);
            this.btnPrint.Size = new System.Drawing.Size(103, 37);
            this.btnPrint.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnPrint.TabIndex = 2;
            this.btnPrint.Text = "چاپ فاکتور";
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnDelete.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(272, 0);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(175, 38);
            this.btnDelete.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnDelete.TabIndex = 1;
            this.btnDelete.Text = "حذف کالا از فاکتور";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnAdd.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(456, 0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(175, 38);
            this.btnAdd.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "افزودن کالا به فاکتور";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(7, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(102, 14);
            this.label16.TabIndex = 0;
            this.label16.Text = "تعداد موجود در انبار";
            // 
            // lblTedad
            // 
            this.lblTedad.AutoSize = true;
            this.lblTedad.BackColor = System.Drawing.Color.Transparent;
            this.lblTedad.ForeColor = System.Drawing.Color.Red;
            this.lblTedad.Location = new System.Drawing.Point(116, 15);
            this.lblTedad.Name = "lblTedad";
            this.lblTedad.Size = new System.Drawing.Size(14, 14);
            this.lblTedad.TabIndex = 0;
            this.lblTedad.Text = "0";
            // 
            // groupPanel3
            // 
            this.groupPanel3.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel3.Controls.Add(this.txtGeymatKharid);
            this.groupPanel3.Controls.Add(this.label15);
            this.groupPanel3.Controls.Add(this.txtTedad);
            this.groupPanel3.Controls.Add(this.txtIdKala);
            this.groupPanel3.Controls.Add(this.label8);
            this.groupPanel3.Controls.Add(this.txtTozih);
            this.groupPanel3.Controls.Add(this.txtIdMoshtari);
            this.groupPanel3.Controls.Add(this.txtGeymatFroosh);
            this.groupPanel3.Controls.Add(this.txtMobile);
            this.groupPanel3.Controls.Add(this.txtNameKala);
            this.groupPanel3.Controls.Add(this.txtNameMoshtari);
            this.groupPanel3.Controls.Add(this.label7);
            this.groupPanel3.Controls.Add(this.label6);
            this.groupPanel3.Controls.Add(this.label14);
            this.groupPanel3.Controls.Add(this.label5);
            this.groupPanel3.Controls.Add(this.label4);
            this.groupPanel3.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel3.Location = new System.Drawing.Point(4, 38);
            this.groupPanel3.Name = "groupPanel3";
            this.groupPanel3.Size = new System.Drawing.Size(642, 86);
            // 
            // 
            // 
            this.groupPanel3.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel3.Style.BackColorGradientAngle = 90;
            this.groupPanel3.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel3.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderBottomWidth = 1;
            this.groupPanel3.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel3.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderLeftWidth = 1;
            this.groupPanel3.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderRightWidth = 1;
            this.groupPanel3.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderTopWidth = 1;
            this.groupPanel3.Style.CornerDiameter = 4;
            this.groupPanel3.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel3.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel3.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel3.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel3.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel3.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel3.TabIndex = 1;
            // 
            // txtGeymatKharid
            // 
            // 
            // 
            // 
            this.txtGeymatKharid.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtGeymatKharid.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtGeymatKharid.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtGeymatKharid.Location = new System.Drawing.Point(324, 53);
            this.txtGeymatKharid.Name = "txtGeymatKharid";
            this.txtGeymatKharid.Size = new System.Drawing.Size(121, 22);
            this.txtGeymatKharid.TabIndex = 6;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Location = new System.Drawing.Point(447, 58);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 14);
            this.label15.TabIndex = 12;
            this.label15.Text = "قیمت خرید";
            // 
            // txtTedad
            // 
            // 
            // 
            // 
            this.txtTedad.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtTedad.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTedad.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtTedad.Location = new System.Drawing.Point(509, 53);
            this.txtTedad.Name = "txtTedad";
            this.txtTedad.ShowUpDown = true;
            this.txtTedad.Size = new System.Drawing.Size(61, 22);
            this.txtTedad.TabIndex = 5;
            this.txtTedad.ValueChanged += new System.EventHandler(this.txtTedad_ValueChanged);
            // 
            // txtIdKala
            // 
            // 
            // 
            // 
            this.txtIdKala.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtIdKala.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtIdKala.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtIdKala.Location = new System.Drawing.Point(467, 28);
            this.txtIdKala.Name = "txtIdKala";
            this.txtIdKala.Size = new System.Drawing.Size(104, 22);
            this.txtIdKala.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(138, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 14);
            this.label8.TabIndex = 0;
            this.label8.Text = "توضیحات";
            // 
            // txtTozih
            // 
            // 
            // 
            // 
            this.txtTozih.Border.Class = "TextBoxBorder";
            this.txtTozih.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtTozih.Location = new System.Drawing.Point(4, 31);
            this.txtTozih.Multiline = true;
            this.txtTozih.Name = "txtTozih";
            this.txtTozih.PreventEnterBeep = true;
            this.txtTozih.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTozih.Size = new System.Drawing.Size(131, 44);
            this.txtTozih.TabIndex = 8;
            // 
            // txtIdMoshtari
            // 
            // 
            // 
            // 
            this.txtIdMoshtari.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtIdMoshtari.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtIdMoshtari.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtIdMoshtari.Location = new System.Drawing.Point(466, 3);
            this.txtIdMoshtari.Name = "txtIdMoshtari";
            this.txtIdMoshtari.Size = new System.Drawing.Size(104, 22);
            this.txtIdMoshtari.TabIndex = 0;
            // 
            // txtGeymatFroosh
            // 
            // 
            // 
            // 
            this.txtGeymatFroosh.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtGeymatFroosh.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtGeymatFroosh.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtGeymatFroosh.Location = new System.Drawing.Point(149, 53);
            this.txtGeymatFroosh.Name = "txtGeymatFroosh";
            this.txtGeymatFroosh.Size = new System.Drawing.Size(106, 22);
            this.txtGeymatFroosh.TabIndex = 7;
            // 
            // txtMobile
            // 
            // 
            // 
            // 
            this.txtMobile.Border.Class = "TextBoxBorder";
            this.txtMobile.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtMobile.Location = new System.Drawing.Point(3, 5);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.PreventEnterBeep = true;
            this.txtMobile.Size = new System.Drawing.Size(131, 22);
            this.txtMobile.TabIndex = 2;
            // 
            // txtNameKala
            // 
            // 
            // 
            // 
            this.txtNameKala.Border.Class = "TextBoxBorder";
            this.txtNameKala.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtNameKala.Location = new System.Drawing.Point(324, 28);
            this.txtNameKala.Name = "txtNameKala";
            this.txtNameKala.PreventEnterBeep = true;
            this.txtNameKala.Size = new System.Drawing.Size(137, 22);
            this.txtNameKala.TabIndex = 4;
            // 
            // txtNameMoshtari
            // 
            // 
            // 
            // 
            this.txtNameMoshtari.Border.Class = "TextBoxBorder";
            this.txtNameMoshtari.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtNameMoshtari.Location = new System.Drawing.Point(222, 3);
            this.txtNameMoshtari.Name = "txtNameMoshtari";
            this.txtNameMoshtari.PreventEnterBeep = true;
            this.txtNameMoshtari.Size = new System.Drawing.Size(239, 22);
            this.txtNameMoshtari.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(254, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 14);
            this.label7.TabIndex = 0;
            this.label7.Text = "قیمت فروش";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(576, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 14);
            this.label6.TabIndex = 0;
            this.label6.Text = "تعداد";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Location = new System.Drawing.Point(574, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 14);
            this.label14.TabIndex = 0;
            this.label14.Text = "کد مشتری";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(575, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 14);
            this.label5.TabIndex = 0;
            this.label5.Text = "کد کالا";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(137, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 14);
            this.label4.TabIndex = 0;
            this.label4.Text = "تلفن همراه";
            // 
            // groupPanel2
            // 
            this.groupPanel2.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel2.Controls.Add(this.txtCodeFactor);
            this.groupPanel2.Controls.Add(this.mskTarikh);
            this.groupPanel2.Controls.Add(this.label2);
            this.groupPanel2.Controls.Add(this.label1);
            this.groupPanel2.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel2.Location = new System.Drawing.Point(4, 1);
            this.groupPanel2.Name = "groupPanel2";
            this.groupPanel2.Size = new System.Drawing.Size(642, 36);
            // 
            // 
            // 
            this.groupPanel2.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel2.Style.BackColorGradientAngle = 90;
            this.groupPanel2.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel2.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderBottomWidth = 1;
            this.groupPanel2.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel2.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderLeftWidth = 1;
            this.groupPanel2.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderRightWidth = 1;
            this.groupPanel2.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderTopWidth = 1;
            this.groupPanel2.Style.CornerDiameter = 4;
            this.groupPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel2.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel2.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel2.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel2.TabIndex = 0;
            // 
            // txtCodeFactor
            // 
            // 
            // 
            // 
            this.txtCodeFactor.BackgroundStyle.Class = "DateTimeInputBackground";
            this.txtCodeFactor.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtCodeFactor.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.txtCodeFactor.Location = new System.Drawing.Point(446, 5);
            this.txtCodeFactor.Name = "txtCodeFactor";
            this.txtCodeFactor.Size = new System.Drawing.Size(104, 22);
            this.txtCodeFactor.TabIndex = 0;
            // 
            // mskTarikh
            // 
            // 
            // 
            // 
            this.mskTarikh.BackgroundStyle.Class = "TextBoxBorder";
            this.mskTarikh.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.mskTarikh.ButtonClear.Visible = true;
            this.mskTarikh.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludeLiterals;
            this.mskTarikh.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Default;
            this.mskTarikh.Location = new System.Drawing.Point(3, 4);
            this.mskTarikh.Mask = "####/##/##";
            this.mskTarikh.Name = "mskTarikh";
            this.mskTarikh.Size = new System.Drawing.Size(132, 21);
            this.mskTarikh.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.mskTarikh.TabIndex = 1;
            this.mskTarikh.Text = "";
            this.mskTarikh.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mskTarikh.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludeLiterals;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(156, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "تاریخ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(556, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "شماره فاکتور";
            // 
            // frmFactorFroosh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 482);
            this.Controls.Add(this.groupPanel1);
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Name = "frmFactorFroosh";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فاکتور فروش";
            this.Load += new System.EventHandler(this.frmFactorFroosh_Load);
            this.groupPanel1.ResumeLayout(false);
            this.groupPanel9.ResumeLayout(false);
            this.groupPanel8.ResumeLayout(false);
            this.groupPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dblFroosh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtHazineh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTakhfif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJameKol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaliyat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtJameFactor)).EndInit();
            this.groupPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKala)).EndInit();
            this.groupPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMoshtari)).EndInit();
            this.groupPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFactor)).EndInit();
            this.groupPanel4.ResumeLayout(false);
            this.groupPanel4.PerformLayout();
            this.groupPanel3.ResumeLayout(false);
            this.groupPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeymatKharid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTedad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIdKala)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIdMoshtari)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGeymatFroosh)).EndInit();
            this.groupPanel2.ResumeLayout(false);
            this.groupPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCodeFactor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel9;
        private DevComponents.DotNetBar.ButtonX btnSanad;
        private DevComponents.DotNetBar.ButtonX btnPardakht;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.ButtonX btnSave;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel8;
        private DevComponents.Editors.DoubleInput dblFroosh;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        public DevComponents.Editors.IntegerInput txtHazineh;
        public DevComponents.Editors.IntegerInput txtTakhfif;
        public DevComponents.Editors.IntegerInput txtJameKol;
        public DevComponents.Editors.IntegerInput txtMaliyat;
        public DevComponents.Editors.IntegerInput txtJameFactor;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel7;
        private DevComponents.DotNetBar.Controls.TextBoxX txtFilterKala;
        private DevComponents.DotNetBar.Controls.DataGridViewX dgvKala;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel6;
        private DevComponents.DotNetBar.Controls.DataGridViewX dgvMoshtari;
        private DevComponents.DotNetBar.Controls.TextBoxX txtFilterMoshtari;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel5;
        private DevComponents.DotNetBar.Controls.DataGridViewX dgvFactor;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel4;
        private DevComponents.DotNetBar.ButtonX btnDelete;
        private DevComponents.DotNetBar.ButtonX btnAdd;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblTedad;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel3;
        private DevComponents.Editors.IntegerInput txtTedad;
        public DevComponents.Editors.IntegerInput txtIdKala;
        public DevComponents.Editors.IntegerInput txtIdMoshtari;
        public DevComponents.Editors.IntegerInput txtGeymatFroosh;
        private DevComponents.DotNetBar.Controls.TextBoxX txtMobile;
        private DevComponents.DotNetBar.Controls.TextBoxX txtNameKala;
        private DevComponents.DotNetBar.Controls.TextBoxX txtNameMoshtari;
        private DevComponents.DotNetBar.Controls.TextBoxX txtTozih;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel2;
        public DevComponents.Editors.IntegerInput txtCodeFactor;
        public DevComponents.DotNetBar.Controls.MaskedTextBoxAdv mskTarikh;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdKala;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameKala;
        private System.Windows.Forms.DataGridViewTextBoxColumn GeymatFroosh;
        private System.Windows.Forms.DataGridViewTextBoxColumn GeymatKharid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tedad;
        private System.Windows.Forms.DataGridViewTextBoxColumn GeymatKolFroosh;
        private System.Windows.Forms.DataGridViewTextBoxColumn GeymatKolKharid;
        public DevComponents.Editors.IntegerInput txtGeymatKharid;
        private System.Windows.Forms.Label label15;
        private DevComponents.DotNetBar.ButtonX btnPrint;
    }
}